<?php
/*
Plugin Name: Themeton Reaction
Plugin URI: http://demo.themeton.com/pressgrid
Description: Post Reactions for Press Grid Wordpress Theme
Author: ThemeTon
Version: 1.0
Author URI: http://www.themeton.com
*/

class Themeton_Reaction{

	function __construct(){
		// Register ajax request
		add_action('wp_ajax_themeton_post_reaction', array($this, 'action_reaction'));
        add_action('wp_ajax_nopriv_themeton_post_reaction', array($this, 'action_reaction'));
	}

	// reaction event
	public function action_reaction(){
		if( isset($_POST['post_id'], $_POST['reaction']) && !empty($_POST['post_id']) ){
			$post_id = abs($_POST['post_id']);
			$reaction = $_POST['reaction'];
			$emotions = (array)get_post_meta($post_id, '_emotions', true);

			$theme_reactions = class_exists('TPL') ? TPL::get_emotions() : array();
            $reaction_keys = array();
            $post_reactions = array();
			foreach ($theme_reactions as $key => $value) {
                $emotion_keys[] = $key;
				if ( array_key_exists($key, $emotions) && abs($emotions[$key])>0 ){
					$post_reactions[$key] = abs($emotions[$key]);
				}
			}

            if( in_array($reaction, $emotion_keys) ){
                $post_reactions[$reaction] = array_key_exists($reaction, $post_reactions) ? abs($post_reactions[$reaction]) + 1 : 1;

                if( !array_key_exists('reactions_of_posts', $_COOKIE) ){
                    setcookie('reactions_of_posts', json_encode(array()), time() + 3600, "/");
                }
                $cookie = isset($_COOKIE['reactions_of_posts']) ? (array)json_decode($_COOKIE['reactions_of_posts']) : array();
                if( !in_array($post_id, $cookie) ){
                    $cookie[] = $post_id;
                }
                setcookie('reactions_of_posts', json_encode($cookie), time() + 3600, "/");
            }

			update_post_meta($post_id , '_emotions', $post_reactions);

			$result = array();
			foreach ($post_reactions as $key => $value){
				$result[] = array( 'emoji'=>$key, 'count'=>abs($value) );
			}

			echo json_encode($result);
		}
		exit;
	}

}

new Themeton_Reaction();